import axios from "axios";
import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';

function EditProject() {
    const { id } = useParams()
    const [name, setName] = useState('');
    const [description, setDescription] = useState();
    const [startDate, setStartDate] = useState();
    const [img, setImg] = useState();
    const [techstack, setTechStack] = useState();
    const [github, setGithub] = useState();
    const [liveUrl, setLiveUrl] = useState();
    const navigate = useNavigate();


    useEffect(() => {
        axios.get('http://localhost:3002/getProject/' + id)
            .then(result => {
                console.log(result)
                setName(result.data.name)
                setDescription(result.data.description)
                setStartDate(result.data.startDate)
                setImg(result.data.img)
                setTechStack(result.data.techstack)
                setGithub(result.data.github)
                setLiveUrl(result.data.liveUrl)
            })
            .catch(err => console.log(`hii ${err}`))
    })


    const Update = (e) => {
        e.preventDefault();
        axios.put("http://localhost:3002/editProject", { name, description, startDate, img, techstack, github, liveUrl })
            .then(result => {
                console.log(name)
                navigate('/')
            })
            .catch(err => console.log(err))
    }


    return (
        <div className='d-flex  vh-100 bg-primary justify-content-center align-items-center'>
            <div className='w-50  bg-white rounded p-3'>
                <form onSubmit={Update}>
                    <h2>Add Project</h2>
                    <div className='mb-2'>
                        <label htmlFor=''>Project Name: </label>
                        <input type='text' placeholder='Enter Project Name' className='form-control'
                            defaultValue={name} onChange={(e) => setName(e.target.value)} />
                    </div>
                    <div className='mb-2'>
                        <label htmlFor=''>Project Description: </label>
                        <input type='text' defaultValue={description} placeholder='Enter Project Description' className='form-control'
                            onChange={(e) => setDescription(e.target.value)} />
                    </div>
                    <div className='mb-2'>
                        <label htmlFor=''>start Date: </label>
                        <input type='text' defaultValue={startDate} placeholder='01-02-23' className='form-control'
                            onChange={(e) => setStartDate(e.target.value)} />
                    </div>
                    <div className='mb-2'>
                        <label htmlFor=''>Project Image: </label>
                        <input type='text' defaultValue={img} placeholder='Image' className='form-control'
                            onChange={(e) => setImg(e.target.value)} />
                    </div>
                    <div className='mb-2'>
                        <label htmlFor=''>Tech stacks/ tags: </label>
                        <input type='text' defaultValue={techstack} placeholder='Enter Project Tech stacks/ tags' className='form-control'
                            onChange={(e) => setTechStack(e.target.value)} />
                    </div>
                    <div className='mb-2'>
                        <label htmlFor=''>Github Link: </label>
                        <input type='text' defaultValue={github} placeholder='Enter Github Link' className='form-control'
                            onChange={(e) => setGithub(e.target.value)} />
                    </div>
                    <div className='mb-2'>
                        <label htmlFor=''>Live Url: </label>
                        <input type='text' defaultValue={liveUrl} placeholder='Enter Live Url' className='form-control'
                            onChange={(e) => setLiveUrl(e.target.value)} />
                    </div>
                    <button className='btn btn-success'>Update</button>

                </form>
            </div>

        </div>
    )
}

export default EditProject;
