import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';
import axios from 'axios';
import 'C:/Users/SKY/Desktop/p/mern/project/src/App.css'

function Projects() {
    const [projects, setProjects] = useState([

    ])
    useEffect(() => {
        axios.get('http://localhost:3002')
            .then(result => setProjects(result.data))
            .catch(err => console.log(err))
    })

    const handleDelete = (id) => {
        axios.delete('http://localhost:3002/deleteProject/' + id)
            .then(res => {
                console.log(res)
                window.location.reload()
            })
            .catch(err => console.log(err))
    }

    return (
        <div className=''>
            <Link to="/create" className='btn btn-success'>Add</Link>
            <div className="Main">
                {projects.map((project) => {
                    return (
                        <div className='card'>
                            <div className="cardimg">
                                <img src={project.img} />
                            </div>
                            <div className="cardcontent">
                                <p>Project Name: {project.name}</p>
                                <p>Project Description: {project.description}</p>
                                <p>Project tag: {project.techstack}</p>
                                <p>Project URL: {project.liveUrl}</p>
                                <div className="btncard">
                                    <Link to={`/update/${project._id}`} className='btn btn-success'>Edit</Link>
                                    <button className='btn btn-danger' onClick={(e) => handleDelete(project._id)}>Delete</button><br />
                                </div>
                            </div>
                        </div>
                    )
                })}
            </div>
        </div>
    )

}

export default Projects;