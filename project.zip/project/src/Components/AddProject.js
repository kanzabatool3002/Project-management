import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function AddProject() {
    const [name, setName] = useState()
    const [description, setDescription] = useState()
    const [startDate, setStartDate] = useState()
    const [img, setImg] = useState()
    const [techstack, setTechStack] = useState()
    const [github, setGithub] = useState()
    const [liveUrl, setLiveUrl] = useState()

    const navigate = useNavigate();

    const Submit = (e) => {
        e.preventDefault();
        axios.post("http://localhost:3002/addProject", { name, description, startDate, img, techstack, github, liveUrl })
            .then(result => {
                console.log(result)
                navigate('/')
            })
            .catch(err => console.log(err))
    }

    return (
        <div className='d-flex  vh-100 bg-primary justify-content-center align-items-center'>
            <div className='w-50  bg-white rounded p-3'>
                <form onSubmit={Submit}>
                    <h2>Add Project</h2>
                    <div className='mb-2'>
                        <label htmlFor=''>Project Name: </label>
                        <input type='text' placeholder='Enter Project Name' className='form-control'
                            onChange={(e) => setName(e.target.value)} />
                    </div>
                    <div className='mb-2'>
                        <label htmlFor=''>Project Description: </label>
                        <input type='text' placeholder='Enter Project Description' className='form-control'
                            onChange={(e) => setDescription(e.target.value)} />
                    </div>
                    <div className='mb-2'>
                        <label htmlFor=''>start Date: </label>
                        <input type='text' placeholder='01-02-23' className='form-control'
                            onChange={(e) => setStartDate(e.target.value)} />
                    </div>
                    <div className='mb-2'>
                        <label htmlFor=''>Project Image: </label>
                        {/* <input
                            type="file"
                            accept=".png, .jpg, .jpeg"
                             name="photo"
                            onChange={(e) => setImg(e.target.files[0])}
                         onChange={handlePhoto}
                        /> */}
                        <input type='text' placeholder='Image' className='form-control'
                            onChange={(e) => setImg(e.target.value)} />
                    </div>
                    <div className='mb-2'>
                        <label htmlFor=''>Tech stacks/ tags: </label>
                        <input type='text' placeholder='Enter Project Tech stacks/ tags' className='form-control'
                            onChange={(e) => setTechStack(e.target.value)} />
                    </div>
                    <div className='mb-2'>
                        <label htmlFor=''>Github Link: </label>
                        <input type='text' placeholder='Enter Github Link' className='form-control'
                            onChange={(e) => setGithub(e.target.value)} />
                    </div>
                    <div className='mb-2'>
                        <label htmlFor=''>Live Url: </label>
                        <input type='text' placeholder='Enter Live Url' className='form-control'
                            onChange={(e) => setLiveUrl(e.target.value)} />
                    </div>
                    <button className='btn btn-success'>Submit</button>

                </form>
            </div>

        </div>
    )
}

export default AddProject;