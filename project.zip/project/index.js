const express = require('express')
const mongoose = require('mongoose')
const cors = require('cors')
const ProjectModel = require('./models/Projects')

const app = express()
app.use(cors())
app.use(express.json())
// app.use(bodyParser.json());
// app.use(bodyParser.urlencoded({ extended: false }));


mongoose.connect("mongodb://127.0.0.1:27017/projects_management")
    .then(() => {
        console.log("mongodb connected");
    })
    .catch(() => {
        console.log('failed');
    })





// app.use(express.urlencoded({ extended: true }))
// app.use(cors())
// app.get("/", cors(), (req, res) => {
// })
// app.post("/", async (req, res) => {
//     const { email, password } = req.body
//     try {
//         const check = await collection.findOne({ email: email })
//         if (check) {
//             res.json("exist")
//         }
//         else {
//             res.json("notexist")
//         }
//     }
//     catch (e) {
//         res.json("fail")
//     }
// })
// app.post("/signup", async (req, res) => {
//     const { email, password } = req.body
//     const data = {
//         email: email,
//         password: password
//     }
//     try {
//         const check = await collection.findMany({ email: email }) 
//         if (check) {
//             res.json("exist")
//         }
//         else {
//             res.json("notexist")
//             await collection.insertMany([data])
//         }
//     }
//     catch (e) {
//         res.json("fail")
//     }
// })



var multer = require('multer');

var storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads')
    },
    filename: (req, file, cb) => {
        cb(null, file.fieldname + '-' + Date.now())
    }
});
var upload = multer({ storage: storage });

app.get('/', (req, res) => {
    ProjectModel.find({})

        .then(projects => res.json(projects))
        // console.log(req.file))
        .catch(err => res.json(err))
})


app.post('/', upload.single('img'), (req, res, next) => {
    var obj = {
        img: {
            data: fs.readFileSync(path.join(__dirname + '/uploads/' + req.file.filename)),
            contentType: 'image/png'
        }
    }
    ProjectModel.create(obj)
        .then((err, item) => {
            if (err) {
                console.log(err);
            }
            else {
                item.save();
                res.redirect('/');
            }
        });
});




app.get('/getProject/:id', (req, res) => {
    const id = req.params.id;
    ProjectModel.findById({ _id: id })
        .then(projects => res.json(projects))
        .catch(err => res.json(err))
})

app.put("/editProject", (req, res) => {
    const id = req.params.id;
    ProjectModel.findByIdAndUpdate({ _id: id }
        , {
            name: req.body.name,
            description: req.body.description,
            startDate: req.body.startDate,
            img: req.body.img,
            techstack: req.body.techstack,
            github: req.body.github,
            liveUrl: req.body.liveUrl
        }
    )
        .then(projects => res.json(projects))
        .catch(err => res.json(err))

})


app.delete('/deleteProject/:id', (req, res) => {
    const id = req.params.id;
    ProjectModel.findByIdAndDelete({ _id: id })
        .then(res => res.json(res))
        .catch(err => res.json(err))
})


app.post("/addProject", (req, res) => {
    ProjectModel.create(req.body)
        .then(projects => res.json(projects))
        .catch(err => res.json(err))
})



app.listen(3002, () => {
    console.log("Server is running")
})


